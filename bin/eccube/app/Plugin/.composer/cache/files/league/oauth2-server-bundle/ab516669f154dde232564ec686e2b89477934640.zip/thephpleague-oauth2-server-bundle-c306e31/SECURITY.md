# Security Policy

DO NOT PUBLISH SECURITY REPORTS PUBLICLY.

If you found any issues that might have security implications, please send a report to robin.chalas[at]gmail.com
