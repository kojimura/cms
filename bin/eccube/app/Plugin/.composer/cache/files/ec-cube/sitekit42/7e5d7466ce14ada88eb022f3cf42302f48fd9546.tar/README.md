# EC-CUBE4 対応の Site Kit プラグイン

EC-CUBE版 Site Kitプラグインです。管理画面にてPageSpeed InsightやGoogle Search Consoleの計測結果を確認することができるようになります。

本プラグインは[WordPressのSite Kitプラグイン](https://wordpress.org/plugins/google-site-kit/)をベースに再構築したものです。

サイトのパフォーマンスや検索トラフィックなどの情報を管理画面上のダッシュボードで一目で確認することができます。

他のプラグインと同様にEC-CUBEの管理画面からインストール可能です。

[オーナーズストアの商品ページはこちら](https://www.ec-cube.net/products/detail.php?product_id=2399)
