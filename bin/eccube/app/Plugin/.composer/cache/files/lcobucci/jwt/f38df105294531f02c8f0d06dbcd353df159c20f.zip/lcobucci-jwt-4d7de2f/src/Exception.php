<?php
declare(strict_types=1);

namespace Lcobucci\JWT;

use Throwable;

interface Exception extends Throwable
{
}
